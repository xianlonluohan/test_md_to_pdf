
from microbit import *
# from dht11 import DHT11
from dht11 import DHT11

DHT11 = DHT11(pin1)
while True:
    # tem,hum=DHT11.read()
    print("temp=",DHT11.read()[0])
    print("hum=",DHT11.read()[1])
    display.scroll(str(DHT11.read()[0])+"C "+str(DHT11.read()[1])+"%")
    # sleep(1000)