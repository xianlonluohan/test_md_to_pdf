import machine
import time


class UltrasonicOneWire:

    def __init__(self, io_pin, echo_timeout_us=200 * 1000) -> None:
        """
        Initializes the RgbUltrasonic class.

        Args:
            io_pin: The IO pin number where the ultrasonic sensor is connected.
        """
        self.pin = machine.Pin(io_pin)
        self.echo_timeout_us = int(echo_timeout_us)

    def distance_cm(self) -> int:
        """
        Measures the distance using the ultrasonic sensor.

        Returns:
            int: The distance measured by the ultrasonic sensor in centimeters.
        """
        self.pin.init(machine.Pin.OUT)
        self.pin.value(0)
        time.sleep_us(5)
        self.pin.value(1)
        time.sleep_us(10)
        self.pin.value(0)

        self.pin.init(machine.Pin.IN)

        duration = machine.time_pulse_us(self.pin, 1, self.echo_timeout_us)

        if duration < 0:
            print("Ultrasonic:", 'out of range')
            return -1

        distance = duration / 2 / 29.1
        return float("%.2f" % distance)
