#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h>

// ============================================US040 - 超声波模块配置============================================

constexpr gpio_num_t kUs04PinTrig = GPIO_NUM_2; // trig pin
constexpr gpio_num_t kUs04PinEcho = GPIO_NUM_1; // echo pin


/**
 * @brief 测量US04超声波传感器的距离
 *
 * 该函数通过控制US04超声波传感器发送触发信号并接收回波信号，
 * 计算出物体与传感器之间的距离。
 *
 * 工作原理：发送10微秒的高电平触发信号，传感器发出超声波脉冲，
 * 当接收到反射回来的超声波时，回波引脚会输出高电平信号，
 * 通过测量高电平持续时间来计算距离。
 *
 * @return float 返回测量到的距离值（单位：厘米）
 *         如果测量超时则返回-1
 */
float MeasureUs04UltrasonicDistance()
{
    // 发送触发信号：先拉低2微秒，再拉高10微秒，然后拉低
    digitalWrite(kUs04PinTrig, LOW);
    delayMicroseconds(2);
    digitalWrite(kUs04PinTrig, HIGH);
    delayMicroseconds(10);
    digitalWrite(kUs04PinTrig, LOW);

    const uint16_t timeout = 30000; // 30毫秒超时时间（约对应5米距离）

    // 测量回波信号的高电平持续时间
    const auto duration = pulseIn(kUs04PinEcho, HIGH, timeout);

    if (duration <= 0)
    {
        printf("Error: US04 sensor measure timeout.\n");
        return -1;
    }
    // 将时间转换为距离：时间(微秒) * 声速(0.034cm/微秒) / 2 (往返距离)
    return static_cast<float>(duration * 0.034 / 2);
}


/**
 * @brief MCP工具 - US04超声波传感器测距功能
 *
 * 该函数注册一个名为 "user.ultrasonic_sensor.get_distance" 的MCP工具，
 * 用于获取US04超声波传感器测量的距离数据
 */
void mcp_tool_us04_ultrasonic_sensor()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              { 
                                  engine.AddMcpTool("user.ultrasonic_sensor.get_distance",  // 工具名称
                                                    "Get distance from US04 ultrasonic sensor", // 工具描述
                                                    {}); // 无参数，传感器自动测量距离
                              });

    // 注册工具处理器，收到调用时，执行超声波测距
    RegisterUserMcpHandler("user.ultrasonic_sensor.get_distance", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 执行距离测量
        const float distance = MeasureUs04UltrasonicDistance();
        
        // 检查测量是否成功
        if (distance < 0) {
            // 测量失败，发送错误响应
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Failed to measure distance from US04 sensor");
        } else {
            // 测量成功，打印日志
            printf("on mcp tool call: user.ultrasonic_sensor.get_distance, distance: %.1f cm\n", distance);
            
            // 发送成功响应，返回距离值
            ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, std::to_string(distance).c_str());
        }
                           });
}


// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);
    delay(500); // 等待串口初始化

    printf("\n========== US04 Initialization ==========\n");
    pinMode(kUs04PinTrig, OUTPUT);
    pinMode(kUs04PinEcho, INPUT);
    printf("========================================\n\n");

    // 注册MCP工具 - US04超声波传感器测距功能
    mcp_tool_us04_ultrasonic_sensor();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}