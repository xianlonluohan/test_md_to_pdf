#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h> 
#include "FastLED.h" // 引入RGB灯的库

#define RGB_PIN 48 // 定义Rgb信号引脚
#define RGB_NUM 12 // 设置Rgb灯环 或灯带的灯珠个数

CRGB leds[RGB_NUM];

// ============================================MCP工具 - RGB灯============================================
/**
 * @brief MCP工具 - 设置RGB灯
 *
 * 该函数注册一个名为 "user.set_rgb_light" 的MCP工具，用于设置RGB灯的状态、亮度和颜色
 */
void mcp_tool_set_rgb_light()
{
    // 注册工具声明器，定义工具的名称、描述和参数
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { engine.AddMcpTool("user.set_all_rgb_light",                        // 工具名称
                        "Set all RGB light state, brightness and color", // 工具描述
                        {
                            {
                                "state",
                                ai_vox::ParamSchema<bool>{
                                    .default_value = std::nullopt, // 状态参数，true为开，false为关
                                },
                            },
                            {
                                "brightness",
                                ai_vox::ParamSchema<int64_t>{
                                    .default_value = 100, // 亮度参数，默认值为100
                                    .min = 0,             // 最小亮度为1
                                    .max = 255,           // 最大亮度为255
                                },
                            },
                            {
                                "r",
                                ai_vox::ParamSchema<int64_t>{
                                    .default_value = 0, // 红色值，默认为0
                                    .min = 0,           // 最小值为0
                                    .max = 255,         // 最大值为255
                                },
                            },
                            {
                                "g",
                                ai_vox::ParamSchema<int64_t>{
                                    .default_value = 0, // 绿色值，默认为0
                                    .min = 0,           // 最小值为0
                                    .max = 255,         // 最大值为255
                                },
                            },
                            {
                                "b",
                                ai_vox::ParamSchema<int64_t>{
                                    .default_value = 0, // 蓝色值，默认为0
                                    .min = 0,           // 最小值为0
                                    .max = 255,         // 最大值为255
                                },
                            },
                        }); });

    // 注册工具处理器，收到调用时，执行设置RGB灯操作
    RegisterUserMcpHandler("user.set_all_rgb_light", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 获取参数
        const auto state_ptr = ev.param<bool>("state");
        const auto brightness_ptr = ev.param<int64_t>("brightness");
        const auto r_ptr = ev.param<int64_t>("r");
        const auto g_ptr = ev.param<int64_t>("g");
        const auto b_ptr = ev.param<int64_t>("b");

        // 检查必需参数是否存在
        if (state_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: state");
            return;
        }

        // 获取参数值，使用默认值
        bool state = *state_ptr;
        int64_t brightness = (brightness_ptr != nullptr) ? *brightness_ptr : 100;
        int64_t r = (r_ptr != nullptr) ? *r_ptr : 0;
        int64_t g = (g_ptr != nullptr) ? *g_ptr : 0;
        int64_t b = (b_ptr != nullptr) ? *b_ptr : 0;

        if (state) {
            FastLED.setBrightness((uint8_t)brightness);
            fill_solid(leds, RGB_NUM, CRGB((uint8_t)r, (uint8_t)g, (uint8_t)b));
            FastLED.show();
        } else {
            fill_solid(leds, RGB_NUM, CRGB::Black);
            FastLED.show();
        }

        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, true); });
}

/**
 * @brief MCP工具 - 设置单个RGB灯珠
 *
 * 该函数注册一个名为 "user.set_single_rgb_light" 的MCP工具，用于设置指定灯珠的状态、亮度和颜色
 */
void mcp_tool_set_single_rgb_light()
{
    // 注册工具声明器，定义工具的名称、描述和参数
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.set_single_rgb_light",               // 工具名称
                          "Set single RGB light state, brightness and color", // 工具描述
                          {
                              {
                                  "index",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 灯珠索引，默认为0
                                      .min = 0,           // 最小索引为0
                                      .max = RGB_NUM - 1, // 最大索引为灯珠总数-1
                                  },
                              },
                              {
                                  "state",
                                  ai_vox::ParamSchema<bool>{
                                      .default_value = std::nullopt, // 状态参数，true为开，false为关
                                  },
                              },
                              {
                                  "brightness",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 100, // 亮度参数，默认值为100
                                      .min = 0,             // 最小亮度为0
                                      .max = 255,           // 最大亮度为255
                                  },
                              },
                              {
                                  "r",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 红色值，默认为0
                                      .min = 0,           // 最小值为0
                                      .max = 255,         // 最大值为255
                                  },
                              },
                              {
                                  "g",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 绿色值，默认为0
                                      .min = 0,           // 最小值为0
                                      .max = 255,         // 最大值为255
                                  },
                              },
                              {
                                  "b",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 蓝色值，默认为0
                                      .min = 0,           // 最小值为0
                                      .max = 255,         // 最大值为255
                                  },
                              },
                          }); 
    });

    // 注册工具处理器，收到调用时，执行设置单个RGB灯珠操作
    RegisterUserMcpHandler("user.set_single_rgb_light", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 获取参数
        const auto index_ptr = ev.param<int64_t>("index");
        const auto state_ptr = ev.param<bool>("state");
        const auto brightness_ptr = ev.param<int64_t>("brightness");
        const auto r_ptr = ev.param<int64_t>("r");
        const auto g_ptr = ev.param<int64_t>("g");
        const auto b_ptr = ev.param<int64_t>("b");

        // 检查必需参数是否存在
        if (state_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: state");
            return;
        }
        
        if (index_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: index");
            return;
        }

        // 获取参数值，使用默认值
        int64_t index = *index_ptr;
        bool state = *state_ptr;
        int64_t brightness = (brightness_ptr != nullptr) ? *brightness_ptr : 100;
        int64_t r = (r_ptr != nullptr) ? *r_ptr : 0;
        int64_t g = (g_ptr != nullptr) ? *g_ptr : 0;
        int64_t b = (b_ptr != nullptr) ? *b_ptr : 0;

        // 验证索引范围
        if (index < 0 || index >= RGB_NUM) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, 
                "Index out of range. Valid range: 0-" + std::to_string(RGB_NUM - 1));
            return;
        }

        if (state) {
            // 设置指定灯珠的颜色
            leds[index] = CRGB((uint8_t)r, (uint8_t)g, (uint8_t)b);
        } else {
            // 关闭指定灯珠
            leds[index] = CRGB::Black;
        }
        
        // 应用亮度设置到整个灯带（影响所有灯珠）
        FastLED.setBrightness((uint8_t)brightness);
        FastLED.show();

        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, true); 
    });
}

/**
 * @brief MCP工具 - 获取单个RGB灯珠状态
 *
 * 该函数注册一个名为 "user.get_single_rgb_light" 的MCP工具，用于获取指定灯珠的状态、亮度和颜色
 */
void mcp_tool_get_single_rgb_light()
{
    // 注册工具声明器，定义工具的名称、描述和参数
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.get_single_rgb_light",               // 工具名称
                          "Get single RGB light state, brightness and color", // 工具描述
                          {
                              {
                                  "index",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 灯珠索引，默认为0
                                      .min = 0,           // 最小索引为0
                                      .max = RGB_NUM - 1, // 最大索引为灯珠总数-1
                                  },
                              },
                          }); 
    });

    // 注册工具处理器，收到调用时，获取指定灯珠的状态信息
    RegisterUserMcpHandler("user.get_single_rgb_light", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 获取参数
        const auto index_ptr = ev.param<int64_t>("index");

        // 检查必需参数是否存在
        if (index_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: index");
            return;
        }

        // 获取参数值
        int64_t index = *index_ptr;

        // 验证索引范围
        if (index < 0 || index >= RGB_NUM) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, 
                "Index out of range. Valid range: 0-" + std::to_string(RGB_NUM - 1));
            return;
        }

        // 获取当前灯珠的状态信息
        CRGB current_color = leds[index];
        uint8_t current_brightness = FastLED.getBrightness();
        
        // 判断灯珠是否开启（如果颜色不是黑色则认为是开启的）
        bool is_on = (current_color != CRGB::Black);

        // 创建 ArduinoJson 文档
        DynamicJsonDocument doc(512); // 分配足够内存
        doc["index"] = index;
        doc["state"] = is_on;
        doc["brightness"] = static_cast<int64_t>(current_brightness);
        doc["r"] = static_cast<int64_t>(current_color.r);
        doc["g"] = static_cast<int64_t>(current_color.g);
        doc["b"] = static_cast<int64_t>(current_color.b);

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应 - 假设 SendMcpCallResponse 可接受字符串
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str()); 
    });
}
// ==============================================================================================================

// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);

    FastLED.addLeds<NEOPIXEL, RGB_PIN>(leds, RGB_NUM);
    FastLED.setBrightness(100);
    FastLED.clear();
    FastLED.show();

    // 初始化RGB灯设置工具
    mcp_tool_set_rgb_light();

    // 初始化单个RGB灯珠设置工具
    mcp_tool_set_single_rgb_light();

    // 获取RGB灯珠状态工具
    mcp_tool_get_single_rgb_light();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}