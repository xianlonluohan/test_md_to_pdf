#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h>
#include "servo.h"

// ============================================舵机配置============================================

constexpr auto kServoPin = 42; // 舵机控制引脚（GPIO 42）

constexpr uint32_t kMinPulse = 500;
constexpr uint32_t kMaxPulse = 2500;
constexpr uint16_t kMaxServoAngle = 180;

auto servo = em::Servo(kServoPin, 0, kMaxServoAngle, kMinPulse, kMaxPulse);

// ============================================MCP工具 - 控制9G舵机============================================

/**
 * @brief MCP工具 - 控制舵机转动
 *
 * 该函数注册一个名为 "user.control_servo" 的MCP工具，用于控制舵机的角度
 */
void mcp_tool_control_servo()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              { engine.AddMcpTool("user.control_servo",  // 工具名称
                                                  "Control servo angle", // 工具描述
                                                  {
                                                      {"angle",
                                                       ai_vox::ParamSchema<int64_t>{
                                                           .default_value = std::nullopt, // 角度参数，默认值为空
                                                           .min = 0,                      // 最小角度为0度
                                                           .max = kMaxServoAngle,         // 最大角度为180度
                                                       }}}); });

    // 注册工具处理器，收到调用时，控制舵机
    RegisterUserMcpHandler("user.control_servo", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 解析参数
        const auto angle_ptr = ev.param<int64_t>("angle");

        // 检查必需参数是否存在
        if (angle_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: angle");
            return;
        }

        // 获取参数值
        int64_t angle = *angle_ptr;

        // 参数验证
        if (angle < 0 || angle > 180) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Angle must be between 0 and 180");
            return;
        }

        // 控制舵机
        servo.Write((uint16_t)angle);
        printf("Servo moved to angle: %d (GPIO %d)\n",  (uint16_t)angle, (int)kServoPin);

        // 创建响应
        DynamicJsonDocument doc(256);
        doc["status"] = "success";
        doc["angle"] = angle;
        doc["gpio"] = (int)kServoPin;

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str()); });
}

// ==============================================================================================================

// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);
    delay(500); // 等待串口初始化

    // ========== 舵机初始化 ==========
    printf("\n========== Servo Initialization ==========\n");

    if (!servo.Init())
    {
        printf("Error: Failed to init servo on pin %d\n", kServoPin);
    }

    servo.Write(90);

    printf("========================================\n\n");

    // 注册MCP工具 - 控制舵机
    mcp_tool_control_servo();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}