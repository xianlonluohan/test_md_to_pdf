#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h> 


#define INB 1  // 定义电机B端口
#define INA 2  // 定义电机A端口


// ============================================MCP工具 - 控制电机============================================

/**
 * @brief MCP工具 - 控制电机转动
 *
 * 该函数注册一个名为 "user.control_motor" 的MCP工具，用于控制电机的正反转和转速
 */
void mcp_tool_control_motor()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.control_motor",          // 工具名称
                          "Control motor direction and speed",  // 工具描述
                          {
                                {
                                  "direction",
                                  ai_vox::ParamSchema<bool>{
                                      .default_value = std::nullopt, // 方向参数，true为正向，false为反向
                                  }
                              },
                              {
                                  "speed",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 转速参数，默认值为0
                                      .min = 0,             // 最小转速为0
                                      .max = 255,           // 最大转速为255
                                  }
                              }
                          }); 
    });

    // 注册工具处理器，收到调用时，控制电机
    RegisterUserMcpHandler("user.control_motor", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 解析参数
        const auto direction = ev.param<bool>("direction");
        const auto speed_ptr = ev.param<int64_t>("speed");

        // 检查必需参数是否存在
        if (direction == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: direction");
            return;
        }

        if (speed_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: speed");
            return;
        }

        // 获取参数值，使用默认值
        bool direction_value = *direction;
        int64_t speed = *speed_ptr;

        // 参数验证
        if (speed < 0 || speed > 255) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Speed must be between 0 and 255");
            return;
        }

        // 控制电机
        if (speed == 0) {
            // 速度为0，立即停止电机，不需要死区延迟
            // 同时清除两个引脚的PWM信号
            analogWrite(INA, 0);
            analogWrite(INB, 0);
            digitalWrite(INA, LOW);
            digitalWrite(INB, LOW);
            printf("Motor stopped\n");
        } else if (direction_value) {
            // 正转：需要死区延迟防止短路
            digitalWrite(INA, LOW);
            digitalWrite(INB, LOW);
            delay(50);  // 死区时间，防止短路（缩短到50ms）
            // 正转：INB低电平，INA使用PWM控制转速
            digitalWrite(INB, LOW);
            analogWrite(INA, (uint8_t)speed);  // 设置转速（0-255）
            printf("Motor running forward: speed=%d\n", (uint8_t)speed);
        } else {
            // 反转：需要死区延迟防止短路
            digitalWrite(INA, LOW);
            digitalWrite(INB, LOW);
            delay(50);  // 死区时间，防止短路（缩短到50ms）
            // 反转：INA低电平，INB使用PWM控制转速
            digitalWrite(INA, LOW);
            analogWrite(INB, (uint8_t)speed);  // 设置转速（0-255）
            printf("Motor running backward: speed=%d\n", (uint8_t)speed);
        }

        printf("Motor running: direction=%s, speed=%d\n", direction_value ? "true" : "false", (uint8_t)speed);

        // 创建响应
        DynamicJsonDocument doc(256);
        doc["status"] = "success";
        doc["direction"] = direction_value;
        doc["speed"] = speed;

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str());
    });
}

// ==============================================================================================================

// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);

    pinMode(INB, OUTPUT);  // 设置电机B端口为输出模式
    pinMode(INA, OUTPUT);  // 设置电机A端口为输出模式

    // 注册MCP工具 - 控制电机
    mcp_tool_control_motor();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}