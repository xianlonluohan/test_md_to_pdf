#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h>
#include <HardwareSerial.h>

// ============================================硬件配置============================================
HardwareSerial UserSerial(2);

const int CUSTOM_TX_PIN = 6; // 自定义TX引脚
const int CUSTOM_RX_PIN = 5; // 自定义RX引脚

// ============================================MCP工具 - ============================================

/**
 * @brief MCP工具 - 串口输出
 *
 * 该函数注册一个名为 "user.uart_output" 的MCP工具，用于通过串口发送数据
 */
void mcp_tool_uart_output()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              { 
        engine.AddMcpTool("user.uart_output",                // 工具名称
                          "Send data through UART serial port. Use this to control external devices connected via serial port.\n"
                          "Examples:\n"
                          "- To turn on LED: 'turn on led'\n", // 工具描述
                          {
                              {"data",
                               ai_vox::ParamSchema<std::string>{
                                   .default_value = std::nullopt,
                               }  // 参数名称和类型
                            }
                          }); 
    });

    // 注册工具处理器，收到调用时，通过串口发送数据
    RegisterUserMcpHandler("user.uart_output", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 解析参数 - 使用正确的参数名 "data"
        const auto data_ptr = ev.param<std::string>("data");

        // 检查必需参数是否存在
        if (data_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: data");
            return;
        }

        // 获取参数值
        std::string data = *data_ptr;

        // 通过串口发送数据
        UserSerial.println(String(data.c_str()));
        printf("UART output: %s\n", data.c_str());

        // 创建响应
        DynamicJsonDocument doc(256);
        doc["status"] = "success";
        doc["sent_data"] = data;
        doc["description"] = "Data sent through UART serial port successfully";

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str()); 
    });
}

// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);
    UserSerial.begin(115200, SERIAL_8N1, CUSTOM_RX_PIN, CUSTOM_TX_PIN);
    delay(500); // 等待串口初始化

    // 注册MCP工具 - 串口输出
    mcp_tool_uart_output();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}