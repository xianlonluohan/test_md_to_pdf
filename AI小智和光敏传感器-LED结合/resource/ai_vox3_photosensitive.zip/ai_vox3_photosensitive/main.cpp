#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"

// ========== MCP 工具 ==========

#define PHOTOSENSITIVE_PIN 3  // 定义光敏传感器模块引脚
#define LED_PIN 1             // 定义LED灯模块引脚

// ========================== ==================MCP工具 - 读取光敏值============================================
/**
 * @brief MCP工具 - 读取光敏值
 *
 * 该函数注册一个名为 "user.read_light_sensor" 的MCP工具，用于读取光敏传感器值
 */
void mcp_tool_read_light_sensor()
{
    // 注册工具声明器，定义工具的名称、描述和参数
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              {
                                  engine.AddMcpTool("user.read_light_sensor",  // 工具名称
                                                    "Read light sensor value", // 工具描述
                                                    {}); // 无参数
                              });

    // 注册工具处理器，收到调用时，执行读取光敏传感器操作
    RegisterUserMcpHandler("user.read_light_sensor", [](const ai_vox::McpToolCallEvent &ev)
    {
        int lightValue = analogRead(PHOTOSENSITIVE_PIN);  // 从光敏传感器引脚读取模拟值
        printf("Light sensor value: %d\n", lightValue);
        
        // 返回读取到的光敏值
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, lightValue); 
    });
}

// ==============================================================================================================

// ============================================MCP工具 - LED 开启/关闭============================================
/**
 * @brief MCP工具 - LED 开启
 *
 * 该函数注册一个名为 "user.led_on" 的MCP工具，用于开启用户LED
 */
void mcp_tool_led_on()
{
    // 注册工具声明器，定义工具的名称、描述和参数
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              {
                                  engine.AddMcpTool("user.led_on",  // 工具名称
                                                    "Turn on user LED", // 工具描述,告诉AI，这个工具是用来打开LED的
                                                    {}); // 无参数
                              });

    // 注册工具处理器，收到调用时，执行打开LED操作（将引脚1设置为高电平）
    RegisterUserMcpHandler("user.led_on", [](const ai_vox::McpToolCallEvent &ev)
    {
        printf("LED on\n");
        digitalWrite(LED_PIN, HIGH);
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, true); 
    });
}

/**
 * @brief MCP工具 - LED 关闭
 *
 * 该函数注册一个名为 "user.led_off" 的MCP工具，用于关闭用户LED
 */
void mcp_tool_led_off()
{
    // 注册工具声明器，定义工具的名称、描述和参数
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              {
                                  engine.AddMcpTool("user.led_off", // 工具名称
                                                    "Turn off user LED",    // 工具描述,告诉AI，这个工具是用来关闭LED的
                                                    {}); // 无参数
                              });

    // 注册工具处理器，收到调用时，执行关闭LED操作（将引脚1设置为低电平）
    RegisterUserMcpHandler("user.led_off", [](const ai_vox::McpToolCallEvent &ev)
                           {
        printf("LED off\n");
        digitalWrite(LED_PIN, LOW);
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, true); });
}

// ==============================================================================================================

// ========== Setup 和 Loop ==========
void setup()
{
    // 设置光敏传感器模块引脚为输入
    pinMode(PHOTOSENSITIVE_PIN, INPUT);  

    // 设置LED模块引脚为输出
    pinMode(LED_PIN, OUTPUT);

    // 初始化读取光敏值工具
    mcp_tool_read_light_sensor();

    // 初始化 LED 开启工具
    mcp_tool_led_on();

    // 初始化 LED 关闭工具
    mcp_tool_led_off();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}
