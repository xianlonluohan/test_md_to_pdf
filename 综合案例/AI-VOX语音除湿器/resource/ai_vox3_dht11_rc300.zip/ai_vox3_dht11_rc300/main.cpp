#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h> 

#include "DHT.h"

// 定义引脚和传感器类型
#define DHTPIN  4     // DHT11 连接的 GPIO 引脚
#define DHTTYPE DHT11 // 指定传感器类型为 DHT11

// 初始化传感器
DHT dht(DHTPIN, DHTTYPE);


#define INB 1  // 定义电机B端口
#define INA 2  // 定义电机A端口

// 在现有代码后添加全局变量
int64_t temp_threshold = 30;    // 温度阈值，默认30°C
int64_t hum_threshold = 70;     // 湿度阈值，默认70%

unsigned long last_sensor_read = 0;  // 上次读取传感器时间
const unsigned long SENSOR_READ_INTERVAL = 2000; // 传感器读取间隔（2秒）

// 添加风扇控制状态标志
bool fan_running = false;

/**
 * @brief MCP工具 - 设置温度阈值
 *
 * 该函数注册一个名为 "user.set_temperature_threshold" 的MCP工具，用于设置温度报警阈值
 */
void mcp_tool_set_temperature_threshold()
{
    // 注册工具声明器
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.set_temperature_threshold",          
                          "Set the temperature threshold for automatic fan control",  
                          {
                            {
                              "threshold",
                              ai_vox::ParamSchema<int64_t>{
                                  .default_value = 30,
                                  .min = 0,
                                  .max = 60,
                              }
                            }
                          }); 
    });

    // 注册工具处理器
    RegisterUserMcpHandler("user.set_temperature_threshold", [](const ai_vox::McpToolCallEvent &ev)
    {
        const auto threshold_ptr = ev.param<int64_t>("threshold");

        if (threshold_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: threshold");
            return;
        }

        int64_t new_threshold = *threshold_ptr;
        
        // 更新温度阈值
        temp_threshold = new_threshold;
        
        printf("Temperature threshold set to: %ld°C\n", temp_threshold);

        // 创建响应
        DynamicJsonDocument doc(128);
        doc["status"] = "success";
        doc["threshold"] = temp_threshold;

        String jsonString;
        serializeJson(doc, jsonString);
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str());
    });
}

/**
 * @brief MCP工具 - 设置湿度阈值
 *
 * 该函数注册一个名为 "user.set_humidity_threshold" 的MCP工具，用于设置湿度报警阈值
 */
void mcp_tool_set_humidity_threshold()
{
    // 注册工具声明器
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.set_humidity_threshold",          
                          "Set the humidity threshold for automatic fan control",  
                          {
                            {
                              "threshold",
                              ai_vox::ParamSchema<int64_t>{
                                  .default_value = 70,
                                  .min = 0,
                                  .max = 100,
                              }
                            }
                          }); 
    });

    // 注册工具处理器
    RegisterUserMcpHandler("user.set_humidity_threshold", [](const ai_vox::McpToolCallEvent &ev)
    {
        const auto threshold_ptr = ev.param<int64_t>("threshold");
        if (threshold_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: threshold");
            return;
        }

        int64_t new_threshold = *threshold_ptr;
        
        // 更新湿度阈值
        hum_threshold = new_threshold;
        
        printf("Humidity threshold set to: %ld\n", hum_threshold);

        // 创建响应
        DynamicJsonDocument doc(128);
        doc["status"] = "success";
        doc["threshold"] = hum_threshold;

        String jsonString;
        serializeJson(doc, jsonString);
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str());
    });
}

// ============================================MCP工具 - 读取温湿度============================================

/**
 * @brief MCP工具 - 读取温湿度数据
 *
 * 该函数注册一个名为 "user.read_temperature_humidity" 的MCP工具，用于读取DHT11传感器的温度和湿度数据
 */
void mcp_tool_read_temperature_humidity()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.read_temperature_humidity",          // 工具名称
                          "Read temperature and humidity from DHT11 sensor",  // 工具描述
                        {}); // 无参数
    });

    // 注册工具处理器，收到调用时，读取温湿度数据
    RegisterUserMcpHandler("user.read_temperature_humidity", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 读取湿度
        float humidity = dht.readHumidity();
        // 读取温度 (摄氏度)
        float temperature = dht.readTemperature();

        printf("====temp:%.2f hum:%.2f\n", temperature, humidity);

        // 检查读取是否成功
        if (isnan(humidity) || isnan(temperature)) {
            Serial.println(F("无法从 DHT 传感器读取数据，请检查接线!"));
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Failed to read from DHT sensor");
            return;
        }

        // 计算体感温度 (Heat Index)
        float hic = dht.computeHeatIndex(temperature, humidity, false);

        // 创建 ArduinoJson 文档
        DynamicJsonDocument doc(256); // 分配足够内存存储温湿度数据
        doc["temperature"] = temperature;
        doc["humidity"] = humidity;
        doc["feels_like_temperature"] = hic;

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str()); 
    });
}

// ============================================MCP工具 - 控制电机============================================

/**
 * @brief MCP工具 - 控制电机转动
 *
 * 该函数注册一个名为 "user.control_motor" 的MCP工具，用于控制电机的正反转和转速
 */
void mcp_tool_control_motor()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
    { 
        engine.AddMcpTool("user.control_motor",          // 工具名称
                          "Control motor direction and speed",  // 工具描述
                          {
                                {
                                  "direction",
                                  ai_vox::ParamSchema<bool>{
                                      .default_value = std::nullopt, // 方向参数，true为正向，false为反向
                                  }
                              },
                              {
                                  "speed",
                                  ai_vox::ParamSchema<int64_t>{
                                      .default_value = 0, // 转速参数，默认值为0
                                      .min = 0,             // 最小转速为0
                                      .max = 255,           // 最大转速为255
                                  }
                              }
                          }); 
    });

    // 注册工具处理器，收到调用时，控制电机
    RegisterUserMcpHandler("user.control_motor", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 解析参数
        const auto direction = ev.param<bool>("direction");
        const auto speed_ptr = ev.param<int64_t>("speed");

        // 检查必需参数是否存在
        if (direction == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: direction");
            return;
        }

        if (speed_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required argument: speed");
            return;
        }

        // 获取参数值，使用默认值
        bool direction_value = *direction;
        int64_t speed = *speed_ptr;

        // 参数验证
        if (speed < 0 || speed > 255) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Speed must be between 0 and 255");
            return;
        }

        // 控制电机
        if (speed == 0) {
            // 速度为0，立即停止电机，不需要死区延迟
            // 同时清除两个引脚的PWM信号
            analogWrite(INA, 0);
            analogWrite(INB, 0);
            digitalWrite(INA, LOW);
            digitalWrite(INB, LOW);
            printf("Motor stopped\n");
        } else if (direction_value) {
            // 正转：需要死区延迟防止短路
            digitalWrite(INA, LOW);
            digitalWrite(INB, LOW);
            delay(50);  // 死区时间，防止短路（缩短到50ms）
            // 正转：INB低电平，INA使用PWM控制转速
            digitalWrite(INB, LOW);
            analogWrite(INA, (uint8_t)speed);  // 设置转速（0-255）
            printf("Motor running forward: speed=%d\n", (uint8_t)speed);
        } else {
            // 反转：需要死区延迟防止短路
            digitalWrite(INA, LOW);
            digitalWrite(INB, LOW);
            delay(50);  // 死区时间，防止短路（缩短到50ms）
            // 反转：INA低电平，INB使用PWM控制转速
            digitalWrite(INA, LOW);
            analogWrite(INB, (uint8_t)speed);  // 设置转速（0-255）
            printf("Motor running backward: speed=%d\n", (uint8_t)speed);
        }

        printf("Motor running: direction=%s, speed=%d\n", direction_value ? "true" : "false", (uint8_t)speed);

        // 创建响应
        DynamicJsonDocument doc(256);
        doc["status"] = "success";
        doc["direction"] = direction_value;
        doc["speed"] = speed;

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str());
    });
}

// ==============================================================================================================

/**
 * @brief 自动检测温湿度并控制风扇
 * 
 * 定期读取温湿度，与阈值比较，超出阈值时自动开启风扇
 */
void auto_control_fan()
{
    // 检查是否已到读取传感器的时间
    if (millis() - last_sensor_read >= SENSOR_READ_INTERVAL) {
        // 读取当前温湿度
        float current_temp = dht.readTemperature();
        float current_hum = dht.readHumidity();

        // 检查读取是否成功
        if (!isnan(current_temp) && !isnan(current_hum)) {
            printf("Current - Temp: %.2f°C, Humidity: %.2f%%\n", current_temp, current_hum);
            printf("Threshold - Temp: %ld°C, Humidity: %ld%%\n", (long)temp_threshold, (long)hum_threshold);

            // 检查是否超过任一阈值
            bool exceed_threshold = (current_temp > temp_threshold || current_hum > hum_threshold);

            if (exceed_threshold && !fan_running) {
                // 超过阈值且风扇未运行，启动风扇
                printf("Threshold exceeded! Starting fan automatically.\n");
                
                // 调用电机控制函数启动风扇（正转，中等速度）
                analogWrite(INA, 150);  // 设置转速为150/255
                digitalWrite(INB, LOW);
                fan_running = true;
                
                printf("Fan started - Temperature: %.2f°C, Humidity: %.2f%%\n", current_temp, current_hum);
            } 
            else if (!exceed_threshold && fan_running) {
                // 未超过阈值但风扇正在运行，关闭风扇
                printf("Values below threshold! Stopping fan automatically.\n");
                
                // 关闭电机
                analogWrite(INA, 0);
                analogWrite(INB, 0);
                digitalWrite(INA, LOW);
                digitalWrite(INB, LOW);
                fan_running = false;
                
                printf("Fan stopped - Temperature: %.2f°C, Humidity: %.2f%%\n", current_temp, current_hum);
            }
        } else {
            Serial.println(F("Failed to read from DHT sensor"));
        }
        
        last_sensor_read = millis();  // 更新最后读取时间
    }
}

// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);

    pinMode(INB, OUTPUT);  // 设置电机B端口为输出模式
    pinMode(INA, OUTPUT);  // 设置电机A端口为输出模式

    // 注册MCP工具 - 读取温湿度
    mcp_tool_read_temperature_humidity();

    // 注册MCP工具 - 控制电机
    mcp_tool_control_motor();

    // 注册MCP工具 - 设置温度阈值
    mcp_tool_set_temperature_threshold();

    // 注册MCP工具 - 设置湿度阈值
    mcp_tool_set_humidity_threshold();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();
}

void loop()
{
    // 执行自动控制风扇功能
    auto_control_fan();

    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}