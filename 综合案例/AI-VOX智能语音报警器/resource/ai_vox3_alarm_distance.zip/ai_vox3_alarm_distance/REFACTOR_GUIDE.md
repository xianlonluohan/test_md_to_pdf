# AI VOX3 代码重构说明文档

## 📋 项目概述

本文档说明如何将复杂的 Arduino 项目代码进行模块化重构，使 `main.cpp` 保持最简洁的框架结构。

---

## 🏗️ 重构方案

### 目录结构

```
ai_vox3/
├── main.cpp                  # Arduino主程序 (简洁框架)
├── ai_vox3_device.h         # 设备接口声明头文件
├── ai_vox3_device.cpp       # 设备实现文件 (所有初始化和事件处理)
├── display.h
├── display.cpp
├── ... (其他文件)
```

---

## 🎯 核心设计

### main.cpp - 最简洁的Arduino框架

```cpp
#include <Arduino.h>
#include "ai_vox3_device.h"

void setup() {
  InitializeDevice();      // 完整初始化
}

void loop() {
  ProcessMainLoop();       // 事件处理
}
```

**特点：**
- 仅保留 Arduino 标准的 `setup()` 和 `loop()` 函数
- 代码简洁，易于理解
- 所有复杂逻辑都被提炼出来

---

## 🔧 模块接口定义

### ai_vox3_device.h

定义了两个核心公共函数：

#### 1. `InitializeDevice()`
**功能：** 完整的设备初始化

**初始化步骤：**
1. 串口初始化
2. LED驱动初始化 (`InitLed()`)
3. I2C总线初始化 (`InitI2cBus()`)
4. 显示屏初始化 (`InitDisplay()`)
5. 音频设备ES8311初始化 (`InitEs8311()`)
6. 按钮初始化 (`InitButton()`)
7. SPIRAM检查
8. WiFi配置 (`ConfigureWifi()`)
9. MCP工具注册 (`InitMcpTools()`)
10. AI引擎初始化和启动

**调用位置：** `setup()` 函数

---

#### 2. `ProcessMainLoop()`
**功能：** 处理主循环中的所有事件

**处理的事件类型：**
- **TextReceivedEvent** - 文本接收事件
- **ActivationEvent** - 设备激活事件
- **StateChangedEvent** - 状态变化事件（Idle, Initted, Loading, Standby, Connecting, Listening, Speaking等）
- **EmotionEvent** - 情绪事件
- **ChatMessageEvent** - 聊天消息事件（用户/助手）
- **McpToolCallEvent** - MCP工具调用事件（音量控制、LED控制）

**可选功能：**
- 内存信息打印（当定义 `PRINT_HEAP_INFO_INTERVAL` 宏时）

**调用位置：** `loop()` 函数

---

## 📁 ai_vox3_device.cpp 结构

### 代码组织

```cpp
// ==================== 配置常量 ====================
// GPIO引脚配置、显示屏配置、音频配置等

// ==================== 全局变量 ====================
// 所有全局设备句柄和对象

// ==================== 硬件初始化函数 ====================
InitI2cBus()
InitEs8311()
InitDisplay()
InitLed()
InitButton()

// ==================== 音频播放函数 ====================
PlayMp3()

// ==================== WiFi配置函数 ====================
ConfigureWifi()

// ==================== MCP工具注册函数 ====================
InitMcpTools()

// ==================== 内存信息打印函数 ====================
PrintMemInfo()

// ==================== 事件处理函数 ====================
HandleMcpToolCall()

// ==================== 公共API实现 ====================
InitializeDevice()
ProcessMainLoop()
```

---

## 🔄 数据流

### 初始化流程

```
setup()
  ↓
InitializeDevice()
  ├─ Serial.begin()
  ├─ InitLed()
  ├─ InitI2cBus()
  ├─ InitDisplay()
  ├─ InitEs8311()
  ├─ InitButton()
  ├─ SPIRAM检查
  ├─ ConfigureWifi()
  ├─ InitMcpTools()
  └─ AI引擎启动
```

### 主循环流程

```
loop()
  ↓
ProcessMainLoop()
  ├─ 打印内存信息(可选)
  ├─ 获取观察者事件队列
  └─ 遍历所有事件
      ├─ 处理文本接收事件
      ├─ 处理激活事件
      ├─ 处理状态变化事件
      ├─ 处理情绪事件
      ├─ 处理聊天消息事件
      └─ 处理MCP工具调用事件
```

---

## 🎛️ 配置修改

### 修改WiFi凭证

在 [ai_vox3_device.cpp](ai_vox3_device.cpp#L76-L77) 中：

```cpp
// WiFi配置
#define WIFI_SSID "Alltman"
#define WIFI_PASSWORD "AlltmanSuccess"
```

### 修改GPIO引脚

在 [ai_vox3_device.cpp](ai_vox3_device.cpp#L35-L62) 中修改对应的常量值。

### 修改AI引擎URL

在 [ai_vox3_device.cpp](ai_vox3_device.cpp) 的 `InitializeDevice()` 函数中：

```cpp
ai_vox_engine.SetOtaUrl("https://api.tenclass.net/xiaozhi/ota/");
ai_vox_engine.ConfigWebsocket("wss://api.tenclass.net/xiaozhi/v1/", {...});
```

---

## 🔌 全局变量

在 `ai_vox3_device.cpp` 的命名空间中定义：

```cpp
i2c_master_bus_handle_t g_i2c_master_bus_handle      // I2C总线句柄
std::shared_ptr<ai_vox::AudioDeviceEs8311> g_audio_device_es8311  // 音频设备
std::unique_ptr<Display> g_display                     // 显示屏
auto g_observer                                        // 事件观察者
button_handle_t g_button_boot_handle                  // 按钮句柄
bool g_led_on                                          // LED状态
led_strip_handle_t g_led_strip                        // LED驱动句柄
```

---

## 💡 优势

| 方面 | 优势 |
|-----|------|
| **可读性** | main.cpp 代码简洁，一眼就能看出整体框架 |
| **维护性** | 所有初始化逻辑集中在一个文件，修改方便 |
| **模块化** | 设备逻辑完全独立，易于单元测试 |
| **扩展性** | 新增功能只需在 ai_vox3_device.cpp 中添加 |
| **代码复用** | 初始化逻辑可被其他项目复用 |

---

## 📝 修改示例

### 添加新的初始化步骤

1. 在 [ai_vox3_device.cpp](ai_vox3_device.cpp) 中编写初始化函数：
```cpp
void InitNewComponent() {
  // 初始化代码...
}
```

2. 在 `InitializeDevice()` 中调用：
```cpp
void InitializeDevice() {
  // ... 其他初始化
  InitNewComponent();
  // ... 其他初始化
}
```

### 添加新的事件处理

1. 在 `ProcessMainLoop()` 中添加事件处理：
```cpp
else if (auto new_event = std::get_if<ai_vox::NewEventType>(&event)) {
  // 处理新事件
}
```

---

## 🚀 编译和部署

使用 Arduino IDE 编译和上传：

1. 确保 [ai_vox3_device.h](ai_vox3_device.h) 和 [ai_vox3_device.cpp](ai_vox3_device.cpp) 与 [main.cpp](main.cpp) 在同一目录
2. 打开 [main.cpp](main.cpp)
3. 编译和上传到 ESP32-S3 开发板

---

## ⚠️ 注意事项

1. **编译顺序**：确保头文件包含正确的顺序
2. **全局变量作用域**：`ai_vox3_device.cpp` 中的全局变量在 `namespace` 中，避免命名冲突
3. **内存管理**：使用了 `std::shared_ptr` 和 `std::unique_ptr`，无需手动释放
4. **WiFi配置**：首次运行时，若未注释掉WiFi凭证宏，会自动连接；否则会进入配网模式

---

## 📚 参考

- [Arduino 官方文档](https://www.arduino.cc/reference/en/)
- [ESP32 开发文档](https://docs.espressif.com/projects/esp-idf/en/latest/)
- [LVGL 显示库](https://docs.lvgl.io/)

---

**最后更新**: 2025年12月25日

