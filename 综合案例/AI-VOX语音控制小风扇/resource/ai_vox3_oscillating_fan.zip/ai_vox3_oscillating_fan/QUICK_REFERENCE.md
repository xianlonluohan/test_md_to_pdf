# 🚀 快速参考指南

## 文件结构

### main.cpp （11 行代码）
最简洁的 Arduino 框架，仅包含：
- 标准包含和编译检查
- `setup()` - 调用 `InitializeDevice()`
- `loop()` - 调用 `ProcessMainLoop()`

### ai_vox3_device.h （头文件）
定义两个公共接口：

```cpp
void InitializeDevice();    // 初始化所有硬件和软件
void ProcessMainLoop();     // 处理每一帧的事件
```

### ai_vox3_device.cpp （实现文件）
包含：
- **配置常量** (GPIO、I2C、WiFi、显示屏等)
- **全局变量** (设备句柄、观察者等)
- **硬件初始化函数** (I2C、LED、显示屏、音频、按钮)
- **功能函数** (音频播放、WiFi配置、工具注册)
- **事件处理** (6种事件类型)
- **两个公共API** (完整的初始化和主循环处理)

---

## 📊 代码行数对比

| 文件 | 原始版本 | 重构后 | 说明 |
|-----|--------|--------|------|
| main.cpp | 591 行 | 18 行 | 98% 代码提炼 |
| ai_vox3_device.cpp | - | 660 行 | 所有逻辑集中 |
| **总行数** | 591 行 | 678 行 | 可读性大幅提升 |

---

## 🎯 核心价值

### 1️⃣ 代码清晰
```cpp
// 原来：main.cpp 591行，混淆的初始化逻辑
// 现在：
void setup() {
  InitializeDevice();
}
```

### 2️⃣ 逻辑独立
- 所有初始化逻辑集中在 `ai_vox3_device.cpp`
- 所有事件处理集中在 `ProcessMainLoop()`
- 易于调试、测试和维护

### 3️⃣ 易于扩展
添加新功能：
1. 在 `ai_vox3_device.cpp` 中添加函数
2. 在 `InitializeDevice()` 或 `ProcessMainLoop()` 中调用
3. `main.cpp` 无需修改

---

## 🔧 初始化流程图

```
setup() → InitializeDevice()
  ├─ Serial.begin(115200)
  ├─ InitLed()
  ├─ InitI2cBus()
  ├─ InitDisplay()
  ├─ InitEs8311()
  ├─ InitButton()
  ├─ SPIRAM检查
  ├─ ConfigureWifi()
  │   └─ 播放通知声音
  │   └─ 显示配网界面
  │   └─ 连接或重新配置
  ├─ InitMcpTools()
  │   ├─ 音量设置工具
  │   ├─ 音量获取工具
  │   ├─ LED开关工具
  │   └─ LED状态工具
  └─ AI引擎启动
```

---

## 📨 事件处理流程图

```
loop() → ProcessMainLoop()
  ├─ 获取事件队列
  └─ 遍历事件
      ├─ TextReceivedEvent → 打印
      ├─ ActivationEvent → 显示激活信息
      ├─ StateChangedEvent → 显示状态
      │   ├─ Idle, Initted, Loading
      │   ├─ LoadingFailed, Standby
      │   ├─ Connecting, Listening, Speaking
      ├─ EmotionEvent → 显示表情
      ├─ ChatMessageEvent → 显示聊天
      │   ├─ 用户消息
      │   └─ 助手回复
      └─ McpToolCallEvent → 工具处理
          ├─ 设置音量
          ├─ 获取音量
          ├─ 控制LED
          └─ 获取LED状态
```

---

## 🎛️ 常见配置修改

### 修改 WiFi

在 `ai_vox3_device.cpp` 第 76-77 行：
```cpp
#define WIFI_SSID "Alltman"
#define WIFI_PASSWORD "AlltmanSuccess"
```

### 修改 GPIO 引脚

在 `ai_vox3_device.cpp` 第 35-62 行修改对应常量：
```cpp
constexpr auto kButtonBoot = GPIO_NUM_0;
constexpr auto kLcdBacklightPin = GPIO_NUM_16;
// ... 更多引脚配置
```

### 修改 AI 引擎 URL

在 `InitializeDevice()` 函数中：
```cpp
ai_vox_engine.SetOtaUrl("https://api.tenclass.net/xiaozhi/ota/");
ai_vox_engine.ConfigWebsocket("wss://api.tenclass.net/xiaozhi/v1/", {...});
```

---

## 🔍 查找关键部分

| 功能 | 位置 | 文件 |
|-----|-----|------|
| GPIO 配置 | 第 35-62 行 | ai_vox3_device.cpp |
| WiFi 配置 | 第 76-77 行 | ai_vox3_device.cpp |
| I2C 初始化 | `InitI2cBus()` | ai_vox3_device.cpp |
| 显示屏初始化 | `InitDisplay()` | ai_vox3_device.cpp |
| 音频初始化 | `InitEs8311()` | ai_vox3_device.cpp |
| WiFi 连接 | `ConfigureWifi()` | ai_vox3_device.cpp |
| 工具注册 | `InitMcpTools()` | ai_vox3_device.cpp |
| 事件处理 | `ProcessMainLoop()` | ai_vox3_device.cpp |

---

## 💾 全局变量速查

```cpp
g_i2c_master_bus_handle         // I2C总线
g_audio_device_es8311           // 音频设备
g_display                       // 显示屏
g_observer                      // 事件观察者
g_button_boot_handle            // 按钮
g_led_on                        // LED状态
g_led_strip                     // LED驱动
```

## ✅ 在 `main.cpp` 中添加用户 MCP 工具与处理器（示例）

在 `setup()` 中于调用 `InitializeDevice()` 之前注册自定义工具声明与处理器：

```cpp
#include "ai_vox3_device.h"
#include "ai_vox_engine.h" // 用于 ai_vox::ParamSchema 等类型

void setup() {
  // 把工具声明交给 engine（将在 InitMcpTools 中被调用）
  RegisterUserMcpDeclarator([](ai_vox::Engine& engine){
    engine.AddMcpTool("user.toggle_led",
                      "Toggle user LED",
                      {
                        {"on", ai_vox::ParamSchema<bool>{.default_value = std::nullopt}},
                      });
  });

  // 注册处理器，当收到名为 "user.toggle_led" 的调用时会被触发
  RegisterUserMcpHandler("user.toggle_led", [](const ai_vox::McpToolCallEvent& ev){
    const auto on_ptr = ev.param<bool>("on");
    if (on_ptr && *on_ptr) {
      digitalWrite(1, HIGH);
      ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, true);
    } else if (on_ptr) {
      digitalWrite(1, LOW);
      ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, true);
    } else {
      ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "missing param: on");
    }
  });

  // 然后调用初始化，InitMcpTools 会执行上面注册的 declarator
  InitializeDevice();
}
```

说明：为了能在 lambda 中使用 `ai_vox::ParamSchema` 等类型，请在 `main.cpp` 中包含 `ai_vox_engine.h`。

---

## ✅ 重构检查清单

- [x] main.cpp 简化为 18 行
- [x] 所有初始化逻辑提炼到 ai_vox3_device.cpp
- [x] 创建 ai_vox3_device.h 头文件
- [x] 所有全局变量集中管理
- [x] 完整的初始化函数实现
- [x] 完整的事件处理函数实现
- [x] 详细文档说明
- [x] 代码注释和分组

---

## 🚀 下一步

1. 验证编译：确保没有编译错误
2. 上传测试：上传到 ESP32-S3 开发板测试
3. 功能验证：检查所有功能是否正常工作
4. 添加功能：使用新的模块化结构添加新功能

---

**文档更新**: 2025年12月25日
