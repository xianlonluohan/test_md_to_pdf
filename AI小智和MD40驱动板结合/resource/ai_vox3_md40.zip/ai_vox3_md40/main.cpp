#include <Arduino.h>
#include "ai_vox3_device.h"
#include "ai_vox_engine.h"
#include <ArduinoJson.h>
#include "Wire.h"

#include "md40.h"

// ============================================硬件配置============================================
constexpr uint16_t kEncoderPpr = 12;
constexpr uint16_t kReductionRatio = 90;

constexpr int kMd40I2cPort = 0;

TwoWire g_motor_wire = TwoWire(2);

em::Md40 g_md40(em::Md40::kDefaultI2cAddress, g_motor_wire);

void init_md40()
{
    g_motor_wire.begin(13, 12);

    g_md40.Init();

    printf("Device ID: 0x");
    printf("%02x\n", g_md40.device_id());
    printf("Name: ");
    printf("%s\n", g_md40.name());
    printf("Firmware Version: ");
    printf("%s\n", g_md40.firmware_version());

    g_md40[0].SetEncoderMode(kEncoderPpr, kReductionRatio, em::Md40::Motor::PhaseRelation::kAPhaseLeads);
    g_md40[0].set_speed_pid_p(1.5);
    g_md40[0].set_speed_pid_i(1.5);
    g_md40[0].set_speed_pid_d(1.0);
    g_md40[0].set_position_pid_p(10.0);
    g_md40[0].set_position_pid_i(1.0);
    g_md40[0].set_position_pid_d(1.0);
}

// 设置MD40电机速度和方向
void setMd40Motor(bool direction, uint8_t speed)
{

    int16_t pwm_duty = map(speed, 0, 100, 0, 1023);

    if (!direction)
    {
        pwm_duty = -pwm_duty;
    }
    printf("Setting MD40 motor: direction=%d, speed=%d, pwm_duty=%d\n", direction, speed, pwm_duty);

    g_md40[0].RunPwmDuty(pwm_duty);
}

// ============================================MCP工具 - 控制MD40电机============================================

/**
 * @brief MCP工具 - 控制MD40电机
 *
 * 该函数注册一个名为 "user.control_md40_motor" 的MCP工具，用于控制MD40电机正反转及速度
 */
void mcp_tool_control_md40_motor()
{
    // 注册工具声明器，定义工具的名称和描述
    RegisterUserMcpDeclarator([](ai_vox::Engine &engine)
                              { engine.AddMcpTool("user.control_md40_motor",                // 工具名称
                                                  "Control MD40 motor direction and speed", // 工具描述
                                                  {
                                                      {"direction",
                                                       ai_vox::ParamSchema<bool>{
                                                           .default_value = std::nullopt, // 方向参数，默认值为空
                                                       }},
                                                      {"speed",
                                                       ai_vox::ParamSchema<int64_t>{
                                                           .default_value = std::nullopt, // 速度参数，默认值为空
                                                           .min = 0,                      // 最小速度为0%
                                                           .max = 100,                    // 最大速度为100%
                                                       }}}); });

    // 注册工具处理器，收到调用时，控制MD40电机
    RegisterUserMcpHandler("user.control_md40_motor", [](const ai_vox::McpToolCallEvent &ev)
                           {
        // 解析参数
        const auto direction_ptr = ev.param<bool>("direction");
        const auto speed_ptr = ev.param<int64_t>("speed");

        // 检查必需参数是否存在
        if (direction_ptr == nullptr || speed_ptr == nullptr) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Missing required arguments: direction and/or speed");
            return;
        }

        // 获取参数值
        bool direction = *direction_ptr;
        int64_t speed = *speed_ptr;

        if (speed < 0 || speed > 100) {
            ai_vox::Engine::GetInstance().SendMcpCallError(ev.id, "Speed must be between 0 and 100");
            return;
        }

        // 控制MD40电机
        setMd40Motor(direction, static_cast<uint8_t>(speed));
        printf("MD40 motor control: direction=%d, speed=%d\n", direction, static_cast<uint8_t>(speed));
        // 创建响应
        DynamicJsonDocument doc(256);
        doc["status"] = "success";
        doc["direction"] = direction;
        doc["speed"] = speed;
        doc["description"] = direction == false ? "Motor REVERSE" : 
                            direction == true ? "Motor FORWARD" : "Motor STOPPED";

        // 将 JSON 文档转换为字符串
        String jsonString;
        serializeJson(doc, jsonString);

        // 发送响应
        ai_vox::Engine::GetInstance().SendMcpCallResponse(ev.id, jsonString.c_str()); });
}

// ========== Setup 和 Loop ==========
void setup()
{
    Serial.begin(115200);
    delay(500); // 等待串口初始化

    // 注册MCP工具 - 控制MD40电机
    mcp_tool_control_md40_motor();

    // 初始化设备服务，包括硬件和AI引擎，必备步骤
    InitializeDevice();

    // 初始化MD40电机
    init_md40();
}

void loop()
{
    // 处理设备服务主循环事件， 必备步骤
    ProcessMainLoop();
}